import React, { useState, useEffect, useCallback } from 'react';
import { View, StyleSheet, Dimensions, Image, FlatList, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import config from '@/config';

const { width } = Dimensions.get('window');

type ImageItem = {
    id: string;
    base64: string;
    createdAt: string;
};

const ClosetScreen = () => {
    const [images, setImages] = useState<ImageItem[]>([]);
    const [refreshing, setRefreshing] = useState(false);
    const [userId, setUserId] = useState<string | null>(null);

    useEffect(() => {
        const fetchUserId = async () => {
            const storedUserId = await AsyncStorage.getItem('userId');
            setUserId(storedUserId);
        };

        fetchUserId().then(() => {
            if (userId) {
                fetchImages(userId);
            }
        });
    }, [userId]);

    const fetchImages = async (userId: string) => {
        try {
            const response = await fetch(`http://${config.serverIP}:3001/api/images?userId=${userId}`);
            const data = await response.json();
            setImages(data);
        } catch (error) {
            console.error('Error fetching images:', error);
        }
    };

    const onRefresh = useCallback(() => {
        if (userId) {
            setRefreshing(true);
            fetchImages(userId).then(() => setRefreshing(false));
        }
    }, [userId]);

    const renderItem = ({ item }: { item: ImageItem }) => {
        return (
            <Image 
                source={{ uri: item.base64 ? `data:image/jpeg;base64,${item.base64}` : undefined }}
                style={styles.image}
                onError={(error) => console.error('Image loading error:', error.nativeEvent.error)}
            />
        );
    };

    return (
        <View style={styles.container}>
            <FlatList
                data={images}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                numColumns={3}
                contentContainerStyle={styles.imageList}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                    />
                }
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    imageList: {
        padding: 5,
    },
    image: {
        width: (width - 30) / 3,  // 3列で表示、左右に5pxのパディング
        aspectRatio: 1,
        margin: 5,
    },
});

export default ClosetScreen;
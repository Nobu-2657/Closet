import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, StyleSheet, Modal, Alert } from 'react-native';
import PushNotification from 'react-native-push-notification';
import AsyncStorage from '@react-native-async-storage/async-storage';
import config from '../../config';

// 災害情報の型定義
type DisasterInfo = {
    type: string;
    time: string;
    epicenter: string;
    magnitude: number;
    maxScale: number;
    tsunami: boolean;
};

const convertMaxScaleToIntensity = (maxScale: number): string => {
    const intensityMap: { [key: number]: string } = {
        10: '1',
        20: '2',
        30: '3',
        40: '4',
        45: '5弱',
        50: '5強',
        55: '6弱',
        60: '6強',
        70: '7'
    };

    return intensityMap[maxScale] || '不明'; // マップにない場合は「不明」を返す
    };

const DisasterAlert: React.FC = () => {
    const [alertVisible, setAlertVisible] = useState<boolean>(false);
    const [disasterInfo, setDisasterInfo] = useState<DisasterInfo | null>(null);
    const [isConnected, setIsConnected] = useState(false);
    const ws = useRef<WebSocket | null>(null);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null); // タイマー用のref

    useEffect(() => {
        // WebSocket接続を確立
        ws.current = new WebSocket(`ws://${config.serverIP}:3002`);

        ws.current.onopen = async () => {
            console.log('WebSocket接続が確立されました');
            const userId = await AsyncStorage.getItem('userId');
            if (userId) {
                ws.current?.send(JSON.stringify({ type: 'register', userId: userId }));
                console.log(`ユーザーID: ${userId} を登録しました`);
            } else {
                console.error('ユーザーIDが見つかりません');
            }
            setIsConnected(true);
        };

        ws.current.onclose = () => {
            console.log('WebSocket接続が閉じられました');
            setIsConnected(false);
        };
    
        ws.current.onerror = (error) => {
            console.error('WebSocket接続エラー:', error);
            setIsConnected(false);
        };

        ws.current.onmessage = async (event) => {
            const data = JSON.parse(event.data);
            if (data.type === 'disaster_alert') {
                setDisasterInfo(data.disasterInfo);
                setAlertVisible(true);
                console.log('災害アラートを受信しました');

                // 10s後に自動的に「危険」と更新
                timeoutRef.current = setTimeout(() => {
                    setAlertVisible(false); // モーダルを閉じる
                }, 10 * 1000); // 10s
            }
        };

        return () => {
            if (ws.current) {
                ws.current.close();
            }
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current); // クリーンアップ
            }
        };
    }, []);

    const handleSafetyResponse = async (status: string) => {
        try {
            const userId = await AsyncStorage.getItem('userId');
            if (!userId) {
                throw new Error('ユーザーIDが見つかりません');
            }
            const response = await fetch(`http://${config.serverIP}:3002/api/update-safety`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    userId: userId || '', // ユーザーIDが存在しない場合は空文字列
                    status: status,
                }),
            });

            if (!response.ok) {
                throw new Error('安全状態の更新に失敗しました');
            }

            Alert.alert('更新完了', '安全状態が更新されました');
            setAlertVisible(false);
        } catch (error) {
            console.error('エラー:', error);
            Alert.alert('エラー', error instanceof Error ? error.message : '安全状態の更新中にエラーが発生しました');
        } finally {
            setAlertVisible(false);
        }
    };

    return (
        <Modal
            animationType="slide"
            transparent={true}
            visible={alertVisible}
            onRequestClose={() => setAlertVisible(false)}
        >
            <View style={styles.centeredView}>
                <View style={styles.modalView}>
                    <Text style={styles.modalTitle}>安全確認</Text>
                    {disasterInfo && (
                        <>
                            <Text>種類: {disasterInfo.type}</Text>
                            <Text>時間: {new Date(disasterInfo.time).toLocaleString()}</Text>
                            <Text>震源地: {disasterInfo.epicenter}</Text>
                            <Text>マグニチュード: {disasterInfo.magnitude}</Text>
                            <Text>震度: {convertMaxScaleToIntensity(disasterInfo.maxScale)}</Text>
                            <Text>津波: {disasterInfo.tsunami ? 'あり' : 'なし'}</Text>
                        </>
                    )}
                    <Text style={styles.question}>現在の状態を選択してください</Text>
                    <View style={styles.buttonContainer}>
                        <Button title="安全" onPress={() => handleSafetyResponse('safe')} color="green" />
                        <Button title="危険" onPress={() => handleSafetyResponse('danger')} color="red" />
                    </View>
                </View>
            </View>
        </Modal>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalView: {
        margin: 20,
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 35,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 15,
    },
    question: {
        fontSize: 16,
        marginTop: 20,
        marginBottom: 10,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        width: '100%',
    },
});

export default DisasterAlert;
//バリデーションチェックを含んだ利用者登録画面（安藤先生作成）
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';
import config from '../../config';

type RootStackParamList = {
  Login: undefined;
  NewLogin: undefined;
  Main: undefined;
  userEdit: undefined;
};

type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {
  navigation: HomeScreenNavigationProp;
};

interface User {
  userId: string;
  lastName: string;
  firstName: string;
  lastNameKana: string;
  firstNameKana: string;
  birthYear: string;
  birthMonth: string;
  birthDay: string;
  gender: string;
  phoneNumber: string;
  email: string;
}

const RegistrationScreen = ({ navigation }: Props) => {
  const [userId, setUserId] = useState('');
  const [lastName, setLastName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastNameKana, setLastNameKana] = useState('');
  const [firstNameKana, setFirstNameKana] = useState('');
  const [birthYear, setBirthYear] = useState('');
  const [birthMonth, setBirthMonth] = useState('1');
  const [birthDay, setBirthDay] = useState('1');
  const [gender, setGender] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [days, setDays] = useState<string[]>([]);
  const [showPassword, setShowPassword] = useState(false);

  const userIdRef = useRef<TextInput>(null);
  const lastNameRef = useRef<TextInput>(null);
  const firstNameRef = useRef<TextInput>(null);
  const lastNameKanaRef = useRef<TextInput>(null);
  const firstNameKanaRef = useRef<TextInput>(null);
  const phoneNumberRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);

  const [lastNameError, setLastNameError] = useState('');
  const [firstNameError, setFirstNameError] = useState('');
  const [lastNameKanaError, setLastNameKanaError] = useState('');
  const [firstNameKanaError, setFirstNameKanaError] = useState('');
  const [phoneNumberError, setPhoneNumberError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    validateName(lastName, 'lastName');
  }, [lastName]);
  
  useEffect(() => {
    validateName(firstName, 'firstName');
  }, [firstName]);

  useEffect(() => {
    validateKana(lastNameKana, 'lastNameKana');
  }, [lastNameKana]);
  
  useEffect(() => {
    validateKana(firstNameKana, 'firstNameKana');
  }, [firstNameKana]);

  const validateName = (name: string, type: 'lastName' | 'firstName') => {
    const kanjiRegex = /^[\u4E00-\u9FAF]+$/;
    if (name && !kanjiRegex.test(name)) {
      if (type === 'lastName') {
        setLastNameError('姓は漢字で入力してください');
      } else {
        setFirstNameError('名は漢字で入力してください');
      }
    } else {
      if (type === 'lastName') {
        setLastNameError('');
      } else {
        setFirstNameError('');
      }
    }
  };

  const validateKana = (kana: string, type: 'lastNameKana' | 'firstNameKana') => {
    const kanaRegex = /^[\u30A0-\u30FF]+$/; // カタカナの正規表現
    if (kana && !kanaRegex.test(kana)) {
      if (type === 'lastNameKana') {
        setLastNameKanaError('姓（カナ）はカタカナで入力してください');
      } else {
        setFirstNameKanaError('名（カナ）はカタカナで入力してください');
      }
    } else {
      if (type === 'lastNameKana') {
        setLastNameKanaError('');
      } else {
        setFirstNameKanaError('');
      }
    }
  };

  // 年、月、日の選択肢を生成
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: currentYear - 1899 }, (_, i) => (1900 + i).toString()); // 年のリスト
  const months = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0')); // 月のリスト

  const updateDaysInMonth = () => {
    if (birthYear && birthMonth) {
      const year = parseInt(birthYear);
      const month = parseInt(birthMonth);
      const daysInMonth = new Date(year, month, 0).getDate(); // 月の日数を取得
      setDays(Array.from({ length: daysInMonth }, (_, i) => (i + 1).toString().padStart(2, '0'))); // 日付を配列に設定
    } else {
      setDays([]); // 年または月が未設定の場合は空配列
    }
  };

  useEffect(() => {
    updateDaysInMonth();
  }, [birthYear, birthMonth]);

  const validatePhoneNumber = (number: string) => {
    const phoneRegex = /^[0-9]{10,11}$/; // 10桁または11桁の数字
    if (!phoneRegex.test(number)) {
      setPhoneNumberError('有効な電話番号を入力してください（10桁または11桁の数字）');
    } else {
      setPhoneNumberError('');
    }
  };
  
  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('有効なメールアドレスを入力してください');
    } else {
      setEmailError('');
    }
  };
  
  const validatePassword = (password: string) => {
    if (password.length < 8) {
      setPasswordError('パスワードは8文字以上で入力してください');
    } else {
      setPasswordError('');
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const validateInputs = () => {
    if (!lastName || !firstName || !lastNameKana || !firstNameKana || !birthYear || !birthMonth || !birthDay || !gender || !phoneNumber || !email || !password) {
      Alert.alert('エラー', 'すべての項目を入力してください。');
      return false;
    }
  
    if (phoneNumberError || emailError || passwordError) {
      Alert.alert('エラー', '入力内容に誤りがあります。修正してください。');
      return false;
    }

    const year = parseInt(birthYear);
    const month = parseInt(birthMonth);
    const day = parseInt(birthDay);
    const currentYear = new Date().getFullYear();

    if (year < 1900 || year > currentYear || month < 1 || month > 12 || day < 1 || day > 31) {
      Alert.alert('エラー', '有効な生年月日を入力してください。');
      return false;
    }

    return true;
  };

  const handleUpdate = async () => {
    if (!validateInputs()) return;
  
    try {
      const response = await fetch(`http://${config.serverIP}:3000/api/users/${user?.userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          lastName,
          firstName,
          lastNameKana,
          firstNameKana,
          birthYear: parseInt(birthYear),
          birthMonth: parseInt(birthMonth),
          birthDay: parseInt(birthDay),
          gender,
          phoneNumber,
          email,
          password,
        }),
      });
  
      const result = await response.json();
  
      if (!response.ok) {
        throw new Error(result.message || '更新に失敗しました');
      }
  
      Alert.alert('成功', 'ユーザー情報が更新されました！');
      navigation.navigate('Main');
    } catch (error) {
      if (error instanceof Error) {
        Alert.alert('エラー', '更新中にエラーが発生しました: ' + error.message);
      } else {
        Alert.alert('エラー', '予期せぬエラーが発生しました');
      }
    }
  };

  //情報表示用の型
  const InfoItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
    <View style={styles.infoItem}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );

  const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    useEffect(() => {
        fetchUserInfo();
    }, []);
    const fetchUserInfo = async () => {
        try {
            const userId = await AsyncStorage.getItem('userId');
            if (!userId) {
                throw new Error('ユーザーIDが見つかりません');
            }
            const response = await fetch(`http://${config.serverIP}:3000/api/users/${userId}`);
            if (!response.ok) {
                throw new Error('ユーザー情報の取得に失敗しました');
            }
            const data = await response.json();
            setUser(data);
        } catch (err) {
            setError('ユーザー情報の取得中にエラーが発生しました');
            console.error(err);
            Alert.alert('エラー', err instanceof Error ? err.message : '未知のエラーが発生しました');
        } finally {
            setLoading(false);
        }
    };
    if (loading) {
        return <ActivityIndicator size="large" />;
    }
    if (error || !user) {
        return <Text>{error || 'ユーザー情報が見つかりません'}</Text>;
    }

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"} 
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <Text style={styles.title}>ユーザー編集</Text>
        <InfoItem label="ユーザID" value={user.userId} />

        <TextInput
          ref={lastNameRef}
          style={styles.input}
          placeholder={user.lastName}
          value={lastName}
          onChangeText={(text) => {
            setLastName(text);
            validateName(text, 'lastName');
          }}
          returnKeyType="next"
          onSubmitEditing={() => firstNameRef.current?.focus()}
        />
        {lastNameError ? <Text style={styles.errorText}>{lastNameError}</Text> : null}

        <TextInput
          ref={firstNameRef}
          style={styles.input}
          placeholder={user.firstName}
          value={firstName}
          onChangeText={(text) => {
            setFirstName(text);
            validateName(text, 'firstName');
          }}
          returnKeyType="next"
          onSubmitEditing={() => lastNameKanaRef.current?.focus()}
        />
        {firstNameError ? <Text style={styles.errorText}>{firstNameError}</Text> : null}

        <TextInput
          ref={lastNameKanaRef}
          style={styles.input}
          placeholder={user.lastNameKana}
          value={lastNameKana}
          onChangeText={(text) => {
            setLastNameKana(text);
            validateKana(text, 'lastNameKana');
          }}
          returnKeyType="next"
          onSubmitEditing={() => firstNameKanaRef.current?.focus()}
        />
        {lastNameKanaError ? <Text style={styles.errorText}>{lastNameKanaError}</Text> : null}

        <TextInput
          ref={firstNameKanaRef}
          style={styles.input}
          placeholder={user.firstNameKana}
          value={firstNameKana}
          onChangeText={(text) => {
            setFirstNameKana(text);
            validateKana(text, 'firstNameKana');
          }}
          returnKeyType="next"
          onSubmitEditing={() => phoneNumberRef.current?.focus()}
        />
        {firstNameKanaError ? <Text style={styles.errorText}>{firstNameKanaError}</Text> : null}

        {/* 生年月日のプルダウンリスト */}
        <Picker
          selectedValue={birthYear}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthYear(itemValue)}
        >
          <Picker.Item label={user.birthYear} value="" />
          {years.map((year) => (
            <Picker.Item key={year} label={year} value={year} />
          ))}
        </Picker>

        <Picker
          selectedValue={birthMonth}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthMonth(itemValue)}
        >
          <Picker.Item label={user.birthMonth} value="" />
          {months.map((month) => (
            <Picker.Item key={month} label={month} value={month} />
          ))}
        </Picker>

        <Picker
          selectedValue={birthDay}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthDay(itemValue)}
        >
          <Picker.Item label={user.birthDay} value="" />
          {days.map((day) => (
            <Picker.Item key={day} label={day} value={day} />
          ))}
        </Picker>

        {/* 性別のプルダウンリスト */}
        <Picker
            selectedValue={gender}
            style={[styles.picker, { height: 55 }]}
            onValueChange={(itemValue) => setGender(itemValue)}
        >
            <Picker.Item label={user.gender === 'male' ? '男性' : user.gender === 'female' ? '女性' : 'その他'} value="" />
            <Picker.Item label="男性" value="male" />
            <Picker.Item label="女性" value="female" />
            <Picker.Item label="その他" value="other" />
        </Picker>

        <TextInput
          ref={phoneNumberRef}
          style={styles.input}
          placeholder={user.phoneNumber}
          value={phoneNumber}
          onChangeText={(text) => {
            setPhoneNumber(text);
            validatePhoneNumber(text);
          }}
          keyboardType="phone-pad"
        />
        {phoneNumberError ? <Text style={styles.errorText}>{phoneNumberError}</Text> : null}

        <TextInput
          ref={emailRef}
          style={styles.input}
          placeholder={user.email}
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            validateEmail(text);
          }}
          keyboardType="email-address"
        />
        {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}

        <View style={styles.passwordContainer}>
          <TextInput
            ref={passwordRef}
            style={styles.passwordInput}
            placeholder="パスワード（8文字以上）"
            value={password}
            onChangeText={(text) => {
              setPassword(text);
              validatePassword(text);
            }}
            secureTextEntry={!showPassword}
          />
          <TouchableOpacity onPress={togglePasswordVisibility} style={styles.visibilityToggle}>
            <Text>{showPassword ? '隠す' : '表示'}</Text>
          </TouchableOpacity>
        </View>
        {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

        <View style={styles.buttonContainer}>
          <Button title="登録" onPress={() => handleUpdate()} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: '#f9f9f9', // 背景色を追加
  },
  buttonContainer: {
    marginTop: 20,
    marginBottom: 40,
  },
  pickerContainer: {
    marginBottom:10,
    borderColor: 'gray',
    borderWidth:1,
    borderRadius:5,
    overflow:'hidden', // 外枠が消えないようにするためのスタイル
    backgroundColor:'#f9f9f9', // 背景色を追加
    },
    picker: {
      height: 50,
      marginBottom: 10,
      backgroundColor: '#f9f9f9',
      borderColor: 'gray',
      borderWidth: 1,
      borderRadius: 5,
    },
    errorText: {
      color: 'red',
      marginBottom: 10,
    },
    infoItem: {
      backgroundColor: '#fff',
      padding: 16,
      marginBottom: 10,
      borderRadius: 8,
    },
    label: {
      fontSize: 14,
      color: '#666',
      marginBottom: 4,
    },
    value: {
      fontSize: 16,
      color: '#333',
    },
    passwordContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
    passwordInput: {
      flex: 1,
      height: 40,
      borderColor: 'gray',
      borderWidth: 1,
      paddingHorizontal: 10,
      borderRadius: 5,
      backgroundColor: '#f9f9f9',
    },
    visibilityToggle: {
      padding: 10,
    },
});

export default RegistrationScreen;
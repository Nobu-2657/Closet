import React, { useEffect, useState } from "react";
import { StyleSheet, View, Button } from "react-native";
import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";
import { Ionicons } from '@expo/vector-icons'; // アイコンをインポート

import { StackNavigationProp } from '@react-navigation/stack';

type RootStackParamList = {
    Home: undefined;
    Detail: undefined;
  };
  
  type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Home'>;
  
  type Props = {
    navigation: HomeScreenNavigationProp;
  };


const Map = () => {
  const [location, setLocation] = useState<Location.LocationObject | undefined>(
    undefined
  );
  
  const [markers, setMarkers] = useState<{ latitude: number; longitude: number, color: string }[]>([]);

  const generateRandomCoordinates = (latitude: number, longitude: number) => {
    const randomLatitude = latitude + (Math.random() - 0.5) * 0.05; // ±0.05度以内
    const randomLongitude = longitude + (Math.random() - 0.5) * 0.05; // ±0.05度以内
    return { latitude: randomLatitude, longitude: randomLongitude };
  };

  const getRandomColor = () => {
    const colors = ['yellow', 'red', 'green']; // 3色の配列
    const randomIndex = Math.floor(Math.random() * colors.length); // ランダムに色を選ぶ
    return colors[randomIndex];
  };

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status === "granted") {
        let location = await Location.getCurrentPositionAsync({});
        setLocation(location);

        // 現在位置を基準にランダムなマーカーを10個生成
        const newMarkers: { latitude: number; longitude: number, color: string }[] = [];
        for (let i = 0; i < 10; i++) {
          const randomCoords = generateRandomCoordinates(
            location.coords.latitude,
            location.coords.longitude
          );
          const randomColor = getRandomColor(); // ランダムに色を取得
          newMarkers.push({ ...randomCoords, color: randomColor });
        }
        setMarkers(newMarkers);
      } else {
        console.log("位置情報の使用を許可しない");
      }
    })();
  }, []);


  
  return (
    <View style={styles.container}>



      <MapView
        style={styles.map}
        initialRegion={
          location && {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }
        }
        showsUserLocation
      >
        {/* ランダムな位置にアイコンを配置 */}
        {markers.map((marker, index) => (
          <Marker key={index} coordinate={{ latitude: marker.latitude, longitude: marker.longitude }}>
            {/* Marker内でIoniconsアイコンを表示 */}
            <Ionicons name="person" size={30} color={marker.color} />
          </Marker>
        ))}
      </MapView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
});

export default Map;

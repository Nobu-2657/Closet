import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions, Image, Text } from 'react-native';
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';
import config from '../../config';

const { width, height } = Dimensions.get('window');

export default function HomeScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [heading, setHeading] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const mapRef = useRef<MapView | null>(null);
  const headingRef = useRef(0);
  const lastUpdateTime = useRef(0);

  useEffect(() => {
    // AsyncStorageからユーザーIDを取得
    const getUserId = async () => {
      try {
        const storedUserId = await AsyncStorage.getItem('userId');
        if (storedUserId) {
          setUserId(storedUserId);
        } else {
          setErrorMsg('ユーザーIDが見つかりません');
        }
      } catch (error) {
        console.error('ユーザーIDの取得に失敗しました:', error);
        setErrorMsg('ユーザーIDの取得に失敗しました');
      }
    };

    getUserId();
  }, []);

  const updateLocationOnServer = async (latitude: number, longitude: number) => {
    if (!userId) {
      console.error('ユーザーIDが設定されていません');
      return;
    }

    try {
      const response = await fetch(`http://${config.serverIP}:3001/update-location`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: userId,
          latitude,
          longitude,
        }),
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      //console.log('Location updated on server:', data);
    } catch (error) {
      console.error('Error updating location on server:', error);
      if (error instanceof Error) {
        console.error('Error message:', error.message);
      }
    }
  };

  const getAndUpdateLocation = async () => {
    if (!userId) {
      console.error('ユーザーIDが設定されていません');
      return;
    }

    try {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('位置情報の許可が必要です');
        return;
      }

      let currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      setLocation(currentLocation);
      updateLocationOnServer(currentLocation.coords.latitude, currentLocation.coords.longitude);

      mapRef.current?.animateCamera({
        center: {
          latitude: currentLocation.coords.latitude,
          longitude: currentLocation.coords.longitude,
        },
      }, { duration: 1000 });
    } catch (error) {
      console.error('Error getting location:', error);
      setErrorMsg('位置情報の取得に失敗しました');
    }
  };

  useEffect(() => {
    if (userId) {
      getAndUpdateLocation(); // 初回実行

      const intervalId = setInterval(() => {
        getAndUpdateLocation(); // 1分ごとに実行
      }, 60000);

      return () => clearInterval(intervalId);
    }
  }, [userId]);

  useEffect(() => {
    const watchHeading = async () => {
      await Location.watchHeadingAsync((headingObject) => {
        const currentTime = Date.now();
        const timeDiff = currentTime - lastUpdateTime.current;
        const newHeading = headingObject.trueHeading;
        
        // ローパスフィルターを適用
        const alpha = 0.1; // フィルター係数
        const filteredHeading = alpha * newHeading + (1 - alpha) * headingRef.current;

        if (timeDiff > 100 && Math.abs(filteredHeading - headingRef.current) > 1) {
          setHeading(filteredHeading);
          headingRef.current = filteredHeading;
          lastUpdateTime.current = currentTime;
        }
      });
    };

    watchHeading();
  }, []);

  if (errorMsg) {
    return <Text>{errorMsg}</Text>;
  }

  return (
    <View style={styles.container}>
      {errorMsg ? (
        <Text>{errorMsg}</Text>
      ) : location ? (
        <MapView
          ref={mapRef}
          style={styles.map}
          initialRegion={{
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
        >
          <Marker
            coordinate={{
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
            }}
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View style={styles.markerWrapper}>
              <Image
                source={require('../assets/direction-arrow.png')}
                style={[
                  styles.markerImage,
                  { transform: [{ rotate: `${heading}deg` }] }
                ]}
                resizeMode="contain"
              />
            </View>
          </Marker>
        </MapView>
      ) : (
        <Text>位置情報を読み込み中...</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    width: width,
    height: height,
  },
  markerWrapper: {
    width: 50,   // コンテナサイズを大きくする
    height: 50,  // コンテナサイズを大きくする
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'transparent',
    //borderWidth: 2, // 枠線の幅
    //borderColor: 'blue', // 枠線の色
    position: 'relative', // 絶対位置指定用
    overflow: 'hidden', // はみ出し部分を隠す
  },
  markerImage: {
    width: 40,   // アイコン画像サイズ
    height: 40, 
    position: 'absolute', // 絶対位置で配置
    //borderWidth: 2, // 枠線の幅
    //borderColor: 'red', // 枠線の色
    top: -5, // 上方向にずらして中心を合わせる
    left: -5, // 左方向にずらして中心を合わせる
  },
});
import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, ActivityIndicator, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';
import config from '../../config';

type RootStackParamList = {
  Login: undefined;
  NewLogin: undefined;
  Index2: undefined;
  userEdit: undefined;
};

type EditScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {
  navigation: EditScreenNavigationProp;
};

interface User {
    userId: string;
    lastName: string;
    firstName: string;
    lastNameKana: string;
    firstNameKana: string;
    birthYear: string;
    birthMonth: string;
    birthDay: string;
    gender: string;
    phoneNumber: string;
    email: string;
}
interface UserInfoScreenProps {
    navigation: any;
}

//情報表示用の型
const InfoItem: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <View style={styles.infoItem}>
    <Text style={styles.label}>{label}</Text>
    <Text style={styles.value}>{value}</Text>
  </View>
);

const UserInfoScreen: React.FC<UserInfoScreenProps> = ({ navigation }:Props) => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    useEffect(() => {
        fetchUserInfo();
    }, []);
    const fetchUserInfo = async () => {
        try {
            const userId = await AsyncStorage.getItem('userId');
            if (!userId) {
                throw new Error('ユーザーIDが見つかりません');
            }
            const response = await fetch(`http://${config.serverIP}:3000/api/users/${userId}`);
            if (!response.ok) {
                throw new Error('ユーザー情報の取得に失敗しました');
            }
            const data = await response.json();
            setUser(data);
        } catch (err) {
            setError('ユーザー情報の取得中にエラーが発生しました');
            console.error(err);
            Alert.alert('エラー', err instanceof Error ? err.message : '未知のエラーが発生しました');
        } finally {
            setLoading(false);
        }
    };
    if (loading) {
        return <ActivityIndicator size="large" />;
    }
    if (error || !user) {
        return <Text>{error || 'ユーザー情報が見つかりません'}</Text>;
    }
    return (
        <ScrollView contentContainerStyle={{ flexGrow: 1, paddingBottom: 40 }} style={styles.container}>
          <Text style={styles.title}>利用者情報</Text>
          <InfoItem label="ユーザID" value={user.userId} />
          <InfoItem label="氏名" value={`${user.lastName} ${user.firstName}`} />
            <InfoItem label="ルビ" value={`${user.lastNameKana} ${user.firstNameKana}`} />
          <InfoItem label="生年月日" value={`${user.birthYear}年${user.birthMonth}月${user.birthDay}日`} />
          <InfoItem 
              label="性別" 
              value={user.gender === 'male' ? '男性' : user.gender === 'female' ? '女性' : 'その他'} 
          />
          <InfoItem label="電話番号" value={user.phoneNumber} />
          <InfoItem label="メールアドレス" value={user.email} />
          <Button title="編集" onPress={() => navigation.navigate('userEdit')} />
        </ScrollView>
        
    );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  nameContainer: {
    marginBottom: 20,
  },
  infoItem: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 10,
    borderRadius: 8,
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  value: {
    fontSize: 16,
    color: '#333',
  },
});
export default UserInfoScreen;
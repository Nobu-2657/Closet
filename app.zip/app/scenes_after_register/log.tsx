import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import config from '../../config';

interface DisasterInfo {
  id: string;
  disasterType: string;
  timestamp: string;
  epicenter: string;
  magnitude: number;
  depth: number;
  latitude: number;
  longitude: number;
  maxScale: number;
  domesticTsunami: string;
  foreignTsunami: string;
  points: {
    pref: string;
    name: string;
    scale: number;
  }[];
}

export default function DisasterLogScreen() {
  const [disasterLogs, setDisasterLogs] = useState<DisasterInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDisasterLogs();
  }, []);

  const fetchDisasterLogs = async () => {
    try {
      const response = await fetch(`http://${config.serverIP}:3000/api/disaster-logs`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setDisasterLogs(data);
      setLoading(false);
    } catch (error) {
      console.error('災害情報の取得に失敗しました:', error);
      setLoading(false);
    }
  };

  const convertMaxScaleToIntensity = (maxScale: number): string => {
    const intensityMap: { [key: number]: string } = {
        10: '1',
        20: '2',
        30: '3',
        40: '4',
        45: '5弱',
        50: '5強',
        55: '6弱',
        60: '6強',
        70: '7'
    };

    return intensityMap[maxScale] || '不明'; // マップにない場合は「不明」を返す
    };

    const convertScaleToIntensity = (scale: number): string => {
      const intensityMap: { [key: number]: string } = {
          10: '1',
          20: '2',
          30: '3',
          40: '4',
          45: '5弱',
          50: '5強',
          55: '6弱',
          60: '6強',
          70: '7'
      };
  
      return intensityMap[scale] || '不明'; // マップにない場合は「不明」を返す
  };

  const DisasterBlock = ({ info }: { info: DisasterInfo }) => (
    <View style={styles.disasterBlock}>
        <Text style={styles.disasterType}>{info.disasterType}</Text>
        <Text style={styles.disasterDate}>
            {new Date(info.timestamp).toLocaleString()}
        </Text>
        <Text>震源: {info.epicenter}</Text>
        <Text>震度: {convertMaxScaleToIntensity(info.maxScale)}</Text>
        <Text>マグニチュード: {info.magnitude}</Text>
        <Text>深さ: {info.depth} km</Text>
        <Text>位置: {info.latitude}, {info.longitude}</Text>
        {info.points.map((point, index) => (
            <Text key={index}>
                {point.pref}: {point.name} (震度: {convertScaleToIntensity(point.scale)})
            </Text>
        ))}
    </View>
);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>災害情報ログ</Text>
      {disasterLogs.map((log) => (
        <DisasterBlock key={log.id} info={log} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  disasterBlock: {
    backgroundColor: '#fff',
    padding: 16,
    marginBottom: 16,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#ff4500',
  },
  disasterType: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  disasterDate: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  disasterDetail: {
    fontSize: 16,
    marginBottom: 4,
  },
});
//バリデーションチェックを含んだ利用者登録画面（安藤先生作成）
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { StackNavigationProp } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import config from '../../config';

type RootStackParamList = {
  Login: undefined;
  NewLogin: undefined;
  Main: undefined;
  userEdit: undefined;
};

type HomeScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {
  navigation: HomeScreenNavigationProp;
};

const RegistrationScreen = ({ navigation }: Props) => {
  const [userId, setUserId] = useState('');
  const [lastName, setLastName] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastNameKana, setLastNameKana] = useState('');
  const [firstNameKana, setFirstNameKana] = useState('');
  const [birthYear, setBirthYear] = useState('');
  const [birthMonth, setBirthMonth] = useState('1');
  const [birthDay, setBirthDay] = useState('1');
  const [gender, setGender] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [days, setDays] = useState<string[]>([]);

  const userIdRef = useRef<TextInput>(null);
  const lastNameRef = useRef<TextInput>(null);
  const firstNameRef = useRef<TextInput>(null);
  const lastNameKanaRef = useRef<TextInput>(null);
  const firstNameKanaRef = useRef<TextInput>(null);
  const phoneNumberRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);

  const [userIdError, setUserIdError] = useState('');
  const [lastNameError, setLastNameError] = useState('');
  const [firstNameError, setFirstNameError] = useState('');
  const [lastNameKanaError, setLastNameKanaError] = useState('');
  const [firstNameKanaError, setFirstNameKanaError] = useState('');
  const [phoneNumberError, setPhoneNumberError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  useEffect(() => {
    if (userId) {
      checkUserId(userId);
    }
  }, [userId]);

  useEffect(() => {
    validateName(lastName, 'lastName');
  }, [lastName]);
  
  useEffect(() => {
    validateName(firstName, 'firstName');
  }, [firstName]);

  useEffect(() => {
    validateKana(lastNameKana, 'lastNameKana');
  }, [lastNameKana]);
  
  useEffect(() => {
    validateKana(firstNameKana, 'firstNameKana');
  }, [firstNameKana]);

  const checkUserId = async (id: string) => {
    try {
      const response = await fetch(`http://${config.serverIP}:3000/api/check-userid?userId=${id}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        throw new TypeError("JSONレスポンスではありません。");
      }
  
      const data = await response.json();
  
      if (data.exists) {
        setUserIdError('このユーザIDは使用できません');
      } else {
        setUserIdError('');
      }
    } catch (error) {
      console.error('ユーザID確認エラー:', error);
      setUserIdError('ユーザIDの確認中にエラーが発生しました');
    }
  };

  const validateName = (name: string, type: 'lastName' | 'firstName') => {
    const kanjiRegex = /^[\u4E00-\u9FAF]+$/;
    if (name && !kanjiRegex.test(name)) {
      if (type === 'lastName') {
        setLastNameError('姓は漢字で入力してください');
      } else {
        setFirstNameError('名は漢字で入力してください');
      }
    } else {
      if (type === 'lastName') {
        setLastNameError('');
      } else {
        setFirstNameError('');
      }
    }
  };

  const validateKana = (kana: string, type: 'lastNameKana' | 'firstNameKana') => {
    const kanaRegex = /^[\u30A0-\u30FF]+$/; // カタカナの正規表現
    if (kana && !kanaRegex.test(kana)) {
      if (type === 'lastNameKana') {
        setLastNameKanaError('姓（カナ）はカタカナで入力してください');
      } else {
        setFirstNameKanaError('名（カナ）はカタカナで入力してください');
      }
    } else {
      if (type === 'lastNameKana') {
        setLastNameKanaError('');
      } else {
        setFirstNameKanaError('');
      }
    }
  };

  // 年、月、日の選択肢を生成
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: currentYear - 1899 }, (_, i) => (1900 + i).toString()); // 年のリスト
  const months = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0')); // 月のリスト

  const updateDaysInMonth = () => {
    if (birthYear && birthMonth) {
      const year = parseInt(birthYear);
      const month = parseInt(birthMonth);
      const daysInMonth = new Date(year, month, 0).getDate(); // 月の日数を取得
      setDays(Array.from({ length: daysInMonth }, (_, i) => (i + 1).toString().padStart(2, '0'))); // 日付を配列に設定
    } else {
      setDays([]); // 年または月が未設定の場合は空配列
    }
  };

  useEffect(() => {
    updateDaysInMonth();
  }, [birthYear, birthMonth]);

  const validatePhoneNumber = (number: string) => {
    const phoneRegex = /^[0-9]{10,11}$/; // 10桁または11桁の数字
    if (!phoneRegex.test(number)) {
      setPhoneNumberError('有効な電話番号を入力してください（10桁または11桁の数字）');
    } else {
      setPhoneNumberError('');
    }
  };
  
  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('有効なメールアドレスを入力してください');
    } else {
      setEmailError('');
    }
  };
  
  const validatePassword = (password: string) => {
    if (password.length < 8) {
      setPasswordError('パスワードは8文字以上で入力してください');
    } else {
      setPasswordError('');
    }
  };

  const validateInputs = () => {
    if (!userId || !lastName || !firstName || !lastNameKana || !firstNameKana || !birthYear || !birthMonth || !birthDay || !gender || !phoneNumber || !email || !password) {
      Alert.alert('エラー', 'すべての項目を入力してください。');
      return false;
    }
  
    if (phoneNumberError || emailError || passwordError) {
      Alert.alert('エラー', '入力内容に誤りがあります。修正してください。');
      return false;
    }

    const year = parseInt(birthYear);
    const month = parseInt(birthMonth);
    const day = parseInt(birthDay);
    const currentYear = new Date().getFullYear();

    if (year < 1900 || year > currentYear || month < 1 || month > 12 || day < 1 || day > 31) {
      Alert.alert('エラー', '有効な生年月日を入力してください。');
      return false;
    }

    return true;
  };

  const handleRegister = async () => {
    if (!validateInputs()) return;

    try {
      const response = await fetch('http://${config.serverIP}:3000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          lastName,
          firstName,
          lastNameKana,
          firstNameKana,
          birthYear: parseInt(birthYear),
          birthMonth: parseInt(birthMonth),
          birthDay: parseInt(birthDay),
          gender,
          phoneNumber,
          email,
          password,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || '登録に失敗しました');
      }

      // ユーザーIDをAsyncStorageに保存
      await AsyncStorage.setItem('userId', userId);

      Alert.alert('成功', '登録が完了しました！ユーザーID: ' + result.userId);
      navigation.navigate('Main');
    } catch (error) {
      if (error instanceof Error) {
        Alert.alert('エラー', '登録中にエラーが発生しました: ' + error.message);
      } else {
        Alert.alert('エラー', '予期せぬエラーが発生しました');
      }
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === "ios" ? "padding" : "height"} 
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <Text style={styles.title}>ユーザー登録</Text>
        <TextInput
          ref={userIdRef}
          style={styles.input}
          placeholder="ユーザーID（例：user123）"
          value={userId}
          onChangeText={(text) => {
            setUserId(text);
            checkUserId(text);
          }}
          returnKeyType="next"
          onSubmitEditing={() => lastNameRef.current?.focus()}
        />
        {userIdError ? <Text style={styles.errorText}>{userIdError}</Text> : null}

        <TextInput
          ref={lastNameRef}
          style={styles.input}
          placeholder="姓（例：山田）"
          value={lastName}
          onChangeText={(text) => {
            setLastName(text);
            validateName(text, 'lastName');
          }}
          returnKeyType="next"
          onSubmitEditing={() => firstNameRef.current?.focus()}
        />
        {lastNameError ? <Text style={styles.errorText}>{lastNameError}</Text> : null}

        <TextInput
          ref={firstNameRef}
          style={styles.input}
          placeholder="名（例：太郎）"
          value={firstName}
          onChangeText={(text) => {
            setFirstName(text);
            validateName(text, 'firstName');
          }}
          returnKeyType="next"
          onSubmitEditing={() => lastNameKanaRef.current?.focus()}
        />
        {firstNameError ? <Text style={styles.errorText}>{firstNameError}</Text> : null}

        <TextInput
          ref={lastNameKanaRef}
          style={styles.input}
          placeholder="姓（カナ）（例：ヤマダ）"
          value={lastNameKana}
          onChangeText={(text) => {
            setLastNameKana(text);
            validateKana(text, 'lastNameKana');
          }}
          returnKeyType="next"
          onSubmitEditing={() => firstNameKanaRef.current?.focus()}
        />
        {lastNameKanaError ? <Text style={styles.errorText}>{lastNameKanaError}</Text> : null}

        <TextInput
          ref={firstNameKanaRef}
          style={styles.input}
          placeholder="名（カナ）（例：タロウ）"
          value={firstNameKana}
          onChangeText={(text) => {
            setFirstNameKana(text);
            validateKana(text, 'firstNameKana');
          }}
          returnKeyType="next"
          onSubmitEditing={() => phoneNumberRef.current?.focus()}
        />
        {firstNameKanaError ? <Text style={styles.errorText}>{firstNameKanaError}</Text> : null}

        {/* 生年月日のプルダウンリスト */}
        <Picker
          selectedValue={birthYear}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthYear(itemValue)}
        >
          <Picker.Item label="生年" value="" />
          {years.map((year) => (
            <Picker.Item key={year} label={year} value={year} />
          ))}
        </Picker>

        <Picker
          selectedValue={birthMonth}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthMonth(itemValue)}
        >
          <Picker.Item label="生月" value="" />
          {months.map((month) => (
            <Picker.Item key={month} label={month} value={month} />
          ))}
        </Picker>

        <Picker
          selectedValue={birthDay}
          style={[styles.picker, { height: 55, marginBottom: 10 }]}
          onValueChange={(itemValue) => setBirthDay(itemValue)}
        >
          <Picker.Item label="生日" value="" />
          {days.map((day) => (
            <Picker.Item key={day} label={day} value={day} />
          ))}
        </Picker>

        {/* 性別のプルダウンリスト */}
        <Picker
            selectedValue={gender}
            style={[styles.picker, { height: 55 }]}
            onValueChange={(itemValue) => setGender(itemValue)}
        >
            <Picker.Item label="性別を選択" value="" />
            <Picker.Item label="男性" value="male" />
            <Picker.Item label="女性" value="female" />
            <Picker.Item label="その他" value="other" />
        </Picker>

        <TextInput
          ref={phoneNumberRef}
          style={styles.input}
          placeholder="電話番号（例：09012345678）"
          value={phoneNumber}
          onChangeText={(text) => {
            setPhoneNumber(text);
            validatePhoneNumber(text);
          }}
          keyboardType="phone-pad"
        />
        {phoneNumberError ? <Text style={styles.errorText}>{phoneNumberError}</Text> : null}

        <TextInput
          ref={emailRef}
          style={styles.input}
          placeholder="メールアドレス（例：example@email.com）"
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            validateEmail(text);
          }}
          keyboardType="email-address"
        />
        {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}

        <TextInput
          ref={passwordRef}
          style={styles.input}
          placeholder="パスワード（8文字以上）"
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            validatePassword(text);
          }}
          secureTextEntry
        />
        {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

        <View style={styles.buttonContainer}>
          <Button title="登録" onPress={() => handleRegister()} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: '#f9f9f9', // 背景色を追加
  },
  buttonContainer: {
    marginTop: 20,
    marginBottom: 40,
  },
  pickerContainer: {
    marginBottom:10,
    borderColor: 'gray',
    borderWidth:1,
    borderRadius:5,
    overflow:'hidden', // 外枠が消えないようにするためのスタイル
    backgroundColor:'#f9f9f9', // 背景色を追加
    },
    picker: {
      height: 50,
      marginBottom: 10,
      backgroundColor: '#f9f9f9',
      borderColor: 'gray',
      borderWidth: 1,
      borderRadius: 5,
    },
    errorText: {
      color: 'red',
      marginBottom: 10,
    },
});

export default RegistrationScreen;
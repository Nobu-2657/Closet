import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';
import userEdit from '../scenes_after_register/useredit';
import config from '../../config';

type RootStackParamList = {
  Login: undefined;
  NewLogin: undefined;
  Main: undefined;
  userEdit: undefined;
};
type LoginScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {
  navigation: LoginScreenNavigationProp;
};



const LoginScreen = ({navigation}:Props) => {
  useEffect(() => {
    const showAsyncStorageContent = async () => {
      try {
        const keys = await AsyncStorage.getAllKeys();
        const result = await AsyncStorage.multiGet(keys);
        console.log('AsyncStorage contents:');
        result.forEach(([key, value]) => console.log(`${key}: ${value}`));
      } catch (error) {
        console.error('Error reading AsyncStorage:', error);
      }
    };
    showAsyncStorageContent();
  }, []);

  const setNull = async()=>{
    try{
      await AsyncStorage.setItem('userId', '0');
    }catch(error){
      console.log(error);
    }
  }

  useEffect(() => {
    const showAsyncStorageContent = async () => {
      try {
        const keys = await AsyncStorage.getAllKeys();
        const result = await AsyncStorage.multiGet(keys);
        console.log('AsyncStorage contents:');
        result.forEach(([key, value]) => console.log(`${key}: ${value}`));
      } catch (error) {
        console.error('Error reading AsyncStorage:', error);
      }
    };
    showAsyncStorageContent();
  }, []);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  //const navigation = useNavigation();
  const handleLogin = async () => {
    try {
      const response = await fetch(`http://${config.serverIP}:3000/api/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      const data = await response.json();
      if (response.ok) {
        // ログイン成功
        Alert.alert('成功', 'ログインに成功しました');
        // ユーザーIDを保存
        await AsyncStorage.setItem('userId', data.user.userId);
        // トークンを保存（セキュリティのため）
        await AsyncStorage.setItem('userToken', data.token);
        // Index2画面に遷移
        navigation.navigate('Main');
      } else {
        // ログイン失敗
        Alert.alert('エラー', data.message || 'ログインに失敗しました');
      }
    } catch (error) {
      console.error('ログインエラー:', error);
      Alert.alert('エラー', 'ログイン中に問題が発生しました。');
    }
  };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>ログイン</Text>
      <Button title="新規登録" onPress={() => navigation.navigate('NewLogin')} />
      <TextInput
        style={styles.input}
        placeholder="メールアドレス"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="パスワード"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="ログイン" onPress={handleLogin} />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: 'white'
  },
  input: {
    height: 40,
    bottom: 10,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 1,
    marginTop: 30,
    paddingHorizontal: 10,
    backgroundColor: 'lavender'
  },
});
export default LoginScreen;
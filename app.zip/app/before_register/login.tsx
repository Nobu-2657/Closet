import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';
import config from '../../config';

type RootStackParamList = {
  Login: undefined;
  Register: undefined;
  Main: undefined;
  userEdit: undefined;
};
type LoginScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Login'>;
type Props = {
  navigation: LoginScreenNavigationProp;
};

const Login = ({ navigation }: Props) => {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    //const [displayName, setDisplayName] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async () => {
      try {
        const response = await fetch(`http://${config.serverIP}:3000/api/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, password }),
        });
        const data = await response.json();
        if (response.ok) {
          // ログイン成功
          Alert.alert('成功', data.message || 'ログインに成功しました');
          
          if (data.user && data.user.displayName) {
            await AsyncStorage.setItem('displayName', data.user.displayName);
          }
          
          if (data.token) {
            await AsyncStorage.setItem('userToken', data.token);
          }
          
          // Index画面に遷移
          navigation.navigate('Main');
        } else {
          // ログイン失敗
          Alert.alert('エラー', data.message || 'ログインに失敗しました');
        }
      } catch (error) {
        console.error('ログインエラー:', error);
        Alert.alert('エラー', 'ログイン中に問題が発生しました。');
      }
    };

    return (
    <View style={styles.container}>
      <Text style={styles.title}>ログイン</Text>
      <TextInput
      style={styles.input}
      placeholder="メールアドレス"
      value={email}
      onChangeText={setEmail}
      />
      <TextInput
      style={styles.input}
      placeholder="パスワード"
      secureTextEntry
      value={password}
      onChangeText={setPassword}
      />
      <Button title="ログイン" onPress={handleLogin} />
      {message ? <Text>{message}</Text> : null}

      <Button 
      title="新規登録はこちら"
      onPress={() => navigation.navigate('Register')} // 新規登録画面に遷移
      />
    </View>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
    },
    title: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 20,
      textAlign: 'center',
      color: 'white'
    },
    input: {
        height: 40,
        borderColor: 'gray',
        borderWidth: 1,
        marginBottom: 10,
        paddingHorizontal: 10,
    },
});

export default Login;